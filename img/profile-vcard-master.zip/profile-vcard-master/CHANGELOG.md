2.0.0 / 2015-08-20
==================

  * update the changelog.md
  * move this to polymer 1.0
  * some fix with the demo page
  * update this to polymer 1.0
  * update this to polymer 1.0
  * we use seed template
  * new demo page
  * old demo style
  * update dependencies
  * update this to V2.0

1.0.0 / 2015-04-22
==================

  * refactor ui, add demo page, contributing, license
  * Fix image error in docs
  * update README.md
  * Demo image
  * :smile: Add D-O-C-S :smile:
  * minimal UI setups, remove profile in header and change color/margins
  * Add .DS_Store to the .gitignore
  * Update README.md
  * Remove social icons, add twitter and website, some color
  * Remove social icons in css
  * Ignore bower components
  * add social icons
  * add new atributes, remove unused atributes
  * add CONTRIBUTING.md
  * create the History.md file
  * first version of the profile card
  * create the demo file
  * refactor bower.json
  * add webcomponentsjs to bower.json
  * add bower.json file for dependencies
  * clean the master repo
  * Merge branch 'gh-pages'
  * mail
  * links open in new window
  * minor bugs
  * fixed about and skills
  * minor changes in style.css
  * the style
  * add images
  * add javascript
  * add font
  * add styles
  * First pages commit
  * Initial commit
