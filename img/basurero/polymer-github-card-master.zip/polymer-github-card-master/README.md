# polymer-github-card

> &lt;github-card&gt; with polymer.


This is a polymer port of [pazguille's](https://github.com/pazguille) great [github-card webcomponent](https://github.com/pazguille/github-card).

![](example.png)

## Demo

[Link](http://ds82.github.io/polymer-github-card/components/demo/)

## Update

Updated component to use polymer 1.0
