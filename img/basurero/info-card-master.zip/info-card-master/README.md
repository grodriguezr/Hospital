# Introduction

This repository contains info-card, a card that displays a picture with some info in a pretty format.

Check out the demo and docs here: https://winhowes.github.io/info-card/components/info-card/.

# Installation
To install simply run:
```
bower install --save info-card
```
